# WAVE Social — build status (v0.2.3)

## Completed in this pass
- Configured `.env` with the active Supabase project URL and its publishable (client-safe) key. No service-role key is included.
- Added `.gitignore` entries for local dependencies, generated native projects, and environment files.
- Kept AsyncStorage-backed Supabase session persistence.
- Added an explicit Android APK build script and incremented app version/versionCode.
- Verified the source ZIP archive integrity and confirmed the live Supabase project is active and has the expected public schema/tables.

## Remote build path added
- Added `.github/workflows/android-apk.yml` to build a debug APK on a GitHub-hosted runner and upload it as a workflow artifact.
- Added `BUILD_ON_GITHUB.md` with setup instructions. The workflow requires two repository secrets for the Supabase URL and publishable key.

## Blocker
- `npm install --no-audit --no-fund` timed out twice in this environment. Dependencies were not installed, so a proper TypeScript build and Android APK build could not be run here.
- No APK is included in this archive. The GitHub Actions workflow has been authored but has not been run, so a successful remote build is not yet confirmed. Do not treat the source as production-ready until dependencies install, typecheck passes, and device-level tests are completed.

## Required validation on a network-enabled machine
1. `npm install --no-audit --no-fund`
2. `npm run typecheck`
3. `npx expo prebuild --platform android`
4. `npm run android:apk`
5. Install `android/app/build/outputs/apk/debug/app-debug.apk` on a device and test sign-up, email confirmation, sign-in/session restoration, room create/list, admin authorization, and error states.

## Features still incomplete
Live audio/WebRTC, speaker seats and mic permissions, realtime chat, secure transactional gift/coin transfer, full moderation/reporting, push notifications, games/battles, and complete admin workflows.

Never embed a Supabase service-role key in the mobile app.
