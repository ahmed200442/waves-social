# WAVE Social — Android starter v0.2.2

Arabic-first Expo / React Native starter with a dark purple/neon direction.

## Included in this iteration
- Email/password sign-up and sign-in using Supabase Auth.
- Persistent mobile auth sessions using React Native AsyncStorage.
- Owner role lookup through the database (`is_owner()`), not solely a client-side email check.
- Owner-only admin screen, selected admin permissions, grant/update/revoke flows.
- Initial profiles, wallets, gifts, gift transactions and audit log schema.
- Additional room, room-member, friendship, and room-message schema.
- Basic room listing/creation and gift catalog display.

## Not production-complete
This is source code, not an APK. Live audio seats, WebRTC/voice provider, realtime chat subscriptions, animated gift assets, secure gift transfers, purchases/payments, complete moderation and reports, push notifications, Ludo, battles, and full admin management screens still require implementation and integration.

## Setup
1. Install Node.js LTS and Android Studio.
2. Run `npm install` (includes React Native AsyncStorage for persistent sessions), then `npm run typecheck`.
3. Copy `.env.example` to `.env`; fill `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
4. For the already-configured Supabase project described in this handoff, apply `003_live_project_compatibility.sql` only. The `001`/`002` files describe an alternate starter schema and should not be applied on top of the live project schema.
5. Enable email/password auth and email confirmation in Supabase.
6. Run `npm start`; use `npx expo prebuild --platform android` and Android Studio/Gradle to build an APK.

## Owner bootstrap
Owner email: `hamadanagy1979@gmail.com`. The app attempts a one-time owner claim only when the signed-in account has this exact email and Supabase reports it as confirmed. The database RLS policy is the enforcement boundary. The owner row has not been verified as created yet; sign in with the confirmed account and check the owner badge after applying the compatibility migration.

## Security
Never put a Supabase `service_role` key in the app. Review RLS policies in a test project before production. The hidden UI is only a convenience; database functions and RLS policies are the actual security boundary. No APK has been built or runtime-tested as part of this starter package.
