# Audit notes — v0.4.3

## Confirmed schema facts
The connected Supabase project has `admins`, `profiles`, `friendships`, `rooms`, `room_members`, `messages`, and `gifts`. Its friendship status constraint allows `pending`, `accepted`, and `blocked`.

## Fix included in source
The application previously used a direct UPDATE against `friend_requests` for rejection while acceptance used an RPC. Migration 014 now removes authenticated UPDATE privilege and uses the same validated `respond_friend_request(p_request_id, p_accept)` RPC for both accept and reject. The RPC checks login, request existence, recipient ownership, and pending status; acceptance also updates `friendships`.

## Remaining risks / validation required
- The new `room_messages`, `friend_requests`, and `direct_messages` tables are introduced by migration 014 and must be created before the corresponding screens can work.
- Verify all foreign keys and RLS policies against the live project before applying migration 014.
- Enable leaked-password protection in Supabase Auth settings.
- Four SECURITY DEFINER functions remain flagged by Supabase Security Advisor; do not revoke EXECUTE without confirming intended RPC use.
- Install dependencies, run `npm run typecheck`, run Expo Android prebuild, build APK, and test authentication, room chat, direct messaging, friend requests, and PK on two accounts/devices.


## Preflight v0.4.6 addition
The read-only preflight now reports duplicate `(requester_id, addressee_id)` pairs, verifies whether an exact valid non-partial unique index exists for the `ON CONFLICT` target, and lists existing friendship RLS policies. Do not run migration 014 if duplicates exist or the unique index check returns no row.
