# WAVE Social — Android starter v0.3.8

Arabic-first Expo / React Native starter with a dark purple/neon direction.

## Included in this iteration
- Email/password sign-up and sign-in using Supabase Auth.
- Persistent mobile auth sessions using React Native AsyncStorage.
- Owner role lookup through the database (`is_owner()`), not solely a client-side email check.
- Owner-only admin screen, selected admin permissions, grant/update/revoke flows.
- Initial profiles, wallets, gifts, gift transactions and audit log schema.
- Additional room, room-member, friendship, and room-message schema.
- Basic room listing/creation and gift catalog display.
- Friend requests, private text messaging, PK challenge creation through a server-validated RPC, accept/decline/cancel flows, duplicate-pending prevention, UUID validation, and visible PK load errors (requires the corresponding SQL migrations).

## Not production-complete
This is source code, not an APK. Live audio seats, WebRTC/voice provider, realtime chat subscriptions, animated gift assets, secure gift transfers, purchases/payments, complete moderation and reports, push notifications, Ludo, battles, and full admin management screens still require implementation and integration.

## Setup
1. Install Node.js LTS and Android Studio.
2. Run `npm install` (includes React Native AsyncStorage for persistent sessions), then `npm run typecheck`.
3. Copy `.env.example` to `.env`; fill `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
4. **Database caution:** do not blindly run all migrations on an existing Supabase project. Migrations `001`–`005` include starter/compatibility schema work, while `006`–`010` add social and PK features with assumptions about tables. Back up the project, inspect its current schema, and apply only compatible migrations in a test project first. PK lifecycle requires migrations `008`, `009`, `010`, and `011` plus the base `pk_matches` table. Migration 011 changes PK creation to a server-validated RPC and revokes direct client inserts; apply it only after validating prior migrations in a test project.
5. Enable email/password auth and email confirmation in Supabase.
6. Run `npm start`; use `npx expo prebuild --platform android` and Android Studio/Gradle to build an APK.

## Owner bootstrap
Owner email: `hamadanagy1979@gmail.com`. The app attempts a one-time owner claim only when the signed-in account has this exact email and Supabase reports it as confirmed. The database RLS policy is the enforcement boundary. The owner row has not been verified as created yet; sign in with the confirmed account and check the owner badge after applying the compatibility migration.

## Security
Never put a Supabase `service_role` key in the app. Review RLS policies in a test project before production. The hidden UI is only a convenience; database functions and RLS policies are the actual security boundary. No APK has been built or runtime-tested as part of this source package. For the exact verified build status, read `IMPLEMENTATION_STATUS.md`.


### Latest source update v0.4.0
Run Supabase migrations `001` through `013` in numeric order in a staging project first. Migration `013` revokes direct PK table writes; challenge lifecycle changes must use the RPC functions. No live database deployment or APK build is claimed by this source update.
