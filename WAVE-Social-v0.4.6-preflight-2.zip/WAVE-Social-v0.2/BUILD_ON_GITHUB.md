# Build WAVE Social APK on GitHub Actions

This project includes `.github/workflows/android-apk.yml`. GitHub's hosted runner installs dependencies, checks TypeScript, generates the Android project, builds a debug APK, and stores it as a downloadable workflow artifact.

## One-time setup

1. Upload/push this project to a GitHub repository (the `.github/workflows` folder must be included).
2. In the repository, open **Settings → Secrets and variables → Actions → New repository secret**.
3. Add these two repository secrets:
   - `EXPO_PUBLIC_SUPABASE_URL` — the Supabase project URL.
   - `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` — the publishable client key (`sb_publishable_...`).
4. Open **Actions → Build WAVE Social Android APK → Run workflow**. A push to `main` or `master` also starts a build.
5. When the run finishes successfully, open the run and download the **wave-social-debug-apk** artifact. Extract it to get `app-debug.apk`.

## Important

- This produces a **debug APK**, not a signed Play Store release.
- Never add a Supabase `service_role` key to app configuration or GitHub secrets used by this mobile build.
- A successful build does not mean all app features are complete. Audio rooms/WebRTC, real-time messaging, secure coin/gift transactions, push notifications, and full moderation/admin workflows still require implementation and device testing.
