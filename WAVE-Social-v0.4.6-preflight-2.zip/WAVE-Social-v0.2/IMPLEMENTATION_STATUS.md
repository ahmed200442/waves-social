# WAVE Social — implementation status (v0.3.7)

## Included in this source package
- Supabase email authentication and session restoration.
- Social rooms and text chat with realtime inserts (audio/video calling is not included).
- Gift catalogue and server-side gift transaction RPC integration.
- Friend requests, friend list and private text messaging with realtime updates.
- Local-only dice/track game prototype (not a complete online Ludo game).
- PK challenge creation, incoming/outgoing challenge list, realtime refresh, and accept/decline RPC migration.
- Owner-only admin entry point and admin role management screen.

## Required before release
1. Apply Supabase migrations `001` through `009` in order in the intended Supabase project.
2. Verify actual database schema, RLS policies, and owner role on the live project.
3. Run `npm install` and `npm run typecheck` in a Node environment with dependencies installed.
4. Build an Android APK and test on physical devices, including two-account PK and private-message flows.
5. Implement actual live audio/video rooms, synchronized multiplayer Ludo, PK live scoring/results, and complete admin operations before calling this a full-featured release.

No claim is made that migrations have been applied to Supabase or that this package has passed a device build/test.

## v0.3.6 follow-up
- Added migration `010_pk_cancel.sql`: only the challenger can cancel their own pending PK challenge; the action is a server-side RPC and rejects already-answered challenges.
- Added a cancel action for outgoing pending PK challenges, with a confirmation prompt.
- Corrected the friends screen note to reflect that direct messaging and realtime message updates are implemented in the client.
- Still requires applying migrations 001–010 in order, installing dependencies, running TypeScript checks, and validating on two authenticated accounts and an Android device. No APK build is claimed for this update.

## v0.3.7 follow-up
- PK list now shows a visible database/query error instead of silently appearing empty; the user can retry loading. This helps distinguish an empty inbox from missing migrations or access-policy errors.
- Updated Expo app version to 0.3.7 and Android versionCode to 4.
- Verification limitation: npm dependency installation timed out in the current environment, so TypeScript and APK builds remain unverified.


## v0.3.8 incremental update
- Replaced direct client inserts for PK challenges with `create_pk_challenge` RPC. The server checks authentication, rejects self-challenges, validates that the target account exists, and rejects an already-pending challenge between the same two users.
- Revoked direct `INSERT` privilege on `pk_matches` for authenticated clients so new challenges go through the validated RPC.
- Added UUID format validation in the UI and specific error messages for invalid or nonexistent opponents and duplicate pending challenges.
- Added migration `011_pk_create_rpc.sql`; apply only after validating migrations 008–010 on a test database.
- Updated app version to 0.3.8 / Android versionCode 5.
- Not yet verified by TypeScript compilation, Supabase execution, device testing, or APK build in this iteration. Live audio, synchronized Ludo, server-authoritative PK scoring, and full admin moderation remain unimplemented.


## v0.3.9 follow-up
- Added migration `012_pk_unique_pending.sql` to prevent duplicate pending PK challenges for the same unordered pair, including concurrent requests.
- Before adding the unique index, legacy duplicate pending challenges are retained only once (oldest remains pending; later duplicates become cancelled).
- Replaced `create_pk_challenge` to return a controlled duplicate-challenge error when concurrent inserts collide.
- Updated Expo version to 0.3.9 / Android versionCode 6.
- This migration has not been applied to the live Supabase project. It should first be tested on a database backup or staging project. TypeScript/APK build and device tests remain unverified.


## v0.4.0 security hardening
- Added migration `013_pk_write_lockdown.sql`: removes direct table write privileges for PK challenges and grants authenticated clients read-only access, leaving create/respond/cancel through validated RPCs.
- This source-only change has not been applied to the live Supabase project or verified by a live database test.
