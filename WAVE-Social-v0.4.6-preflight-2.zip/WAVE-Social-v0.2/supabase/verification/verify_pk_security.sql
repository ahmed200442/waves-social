-- WAVE Social: post-migration verification for PK challenge security.
-- Run in Supabase SQL Editor AFTER migrations 001-013 have been applied.
-- This is read-only: it reports checks and does not change database state.

with checks as (
  select 'RLS enabled on pk_matches'::text as check_name,
         coalesce((select c.relrowsecurity from pg_class c
                   join pg_namespace n on n.oid = c.relnamespace
                   where n.nspname = 'public' and c.relname = 'pk_matches'), false) as passed,
         'public.pk_matches must have row-level security enabled'::text as detail
  union all
  select 'Authenticated can SELECT pk_matches',
         has_table_privilege('authenticated', 'public.pk_matches', 'SELECT'),
         'Participants need SELECT; the participant RLS policy limits visible rows'
  union all
  select 'Authenticated cannot INSERT directly',
         not has_table_privilege('authenticated', 'public.pk_matches', 'INSERT'),
         'Creation must go through create_pk_challenge(uuid)'
  union all
  select 'Authenticated cannot UPDATE directly',
         not has_table_privilege('authenticated', 'public.pk_matches', 'UPDATE'),
         'Status and scores must not be changed by direct table writes'
  union all
  select 'Authenticated cannot DELETE directly',
         not has_table_privilege('authenticated', 'public.pk_matches', 'DELETE'),
         'Challenge deletion must not be available to clients'
  union all
  select 'Anon cannot SELECT pk_matches',
         not has_table_privilege('anon', 'public.pk_matches', 'SELECT'),
         'Unauthenticated clients must not read challenges'
  union all
  select 'Participant SELECT policy exists',
         exists (
           select 1 from pg_policies
           where schemaname = 'public'
             and tablename = 'pk_matches'
             and cmd = 'SELECT'
             and qual ilike '%challenger_id%'
             and qual ilike '%opponent_id%'
         ),
         'Policy should allow a user to read rows where they are challenger or opponent'
  union all
  select 'create_pk_challenge is SECURITY DEFINER',
         coalesce((select p.prosecdef from pg_proc p
                   join pg_namespace n on n.oid = p.pronamespace
                   where n.nspname = 'public'
                     and p.proname = 'create_pk_challenge'
                     and pg_get_function_identity_arguments(p.oid) = 'p_opponent_id uuid'), false),
         'The RPC must perform validated inserts with owner privileges'
  union all
  select 'respond_pk_challenge is SECURITY DEFINER',
         coalesce((select p.prosecdef from pg_proc p
                   join pg_namespace n on n.oid = p.pronamespace
                   where n.nspname = 'public'
                     and p.proname = 'respond_pk_challenge'
                     and pg_get_function_identity_arguments(p.oid) = 'p_match_id uuid, p_accept boolean'), false),
         'The RPC must validate that only the invited opponent responds'
  union all
  select 'cancel_pk_challenge is SECURITY DEFINER',
         coalesce((select p.prosecdef from pg_proc p
                   join pg_namespace n on n.oid = p.pronamespace
                   where n.nspname = 'public'
                     and p.proname = 'cancel_pk_challenge'
                     and pg_get_function_identity_arguments(p.oid) = 'p_match_id uuid'), false),
         'The RPC must validate that only the challenger cancels'
  union all
  select 'Unique pending challenge index exists',
         exists (select 1 from pg_indexes
                 where schemaname = 'public'
                   and tablename = 'pk_matches'
                   and indexname = 'pk_matches_one_pending_per_pair_uidx'),
         'Prevents concurrent duplicate pending challenges for the same pair'
)
select check_name,
       case when passed then 'PASS' else 'FAIL' end as result,
       detail
from checks
order by passed asc, check_name asc;
