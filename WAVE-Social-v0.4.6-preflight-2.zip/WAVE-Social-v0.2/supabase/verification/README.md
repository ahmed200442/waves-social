# PK security verification

1. Apply migrations `001` through `013` in order in the intended Supabase project.
2. Open Supabase SQL Editor and run `verify_pk_security.sql`.
3. Review the result column. Every row should show `PASS`.
4. If a row shows `FAIL`, do not treat PK challenge security as verified; share the failing check name and result for diagnosis.

The verification query is read-only. It does not apply migrations, alter grants, or change application data.
