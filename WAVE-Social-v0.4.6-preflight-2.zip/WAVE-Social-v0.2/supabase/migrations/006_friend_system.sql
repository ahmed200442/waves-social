-- WAVE Social migration 006: friend requests and accepted friendships.
create table if not exists public.friend_requests (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references auth.users(id) on delete cascade,
 receiver_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted','rejected','cancelled')),
 created_at timestamptz not null default now(),
 responded_at timestamptz,
 constraint friend_requests_not_self check(sender_id <> receiver_id),
 constraint friend_requests_unique_pair unique(sender_id,receiver_id)
);
create index if not exists friend_requests_receiver_status_idx on public.friend_requests(receiver_id,status,created_at desc);

create table if not exists public.friendships (
 user_a uuid not null references auth.users(id) on delete cascade,
 user_b uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(user_a,user_b),
 constraint friendships_ordered_pair check(user_a < user_b)
);
create index if not exists friendships_user_b_idx on public.friendships(user_b,created_at desc);

alter table public.friend_requests enable row level security;
alter table public.friendships enable row level security;

 drop policy if exists friend_requests_participant_read on public.friend_requests;
create policy friend_requests_participant_read on public.friend_requests for select to authenticated
 using(sender_id=(select auth.uid()) or receiver_id=(select auth.uid()));
drop policy if exists friend_requests_sender_create on public.friend_requests;
create policy friend_requests_sender_create on public.friend_requests for insert to authenticated
 with check(sender_id=(select auth.uid()) and receiver_id<>(select auth.uid()) and status='pending');
drop policy if exists friend_requests_receiver_update on public.friend_requests;
create policy friend_requests_receiver_update on public.friend_requests for update to authenticated
 using(receiver_id=(select auth.uid()) and status='pending')
 with check(receiver_id=(select auth.uid()) and status in ('accepted','rejected'));
drop policy if exists friendships_participant_read on public.friendships;
create policy friendships_participant_read on public.friendships for select to authenticated
 using(user_a=(select auth.uid()) or user_b=(select auth.uid()));
revoke all on public.friend_requests from anon;
revoke all on public.friendships from anon,authenticated;
grant select,insert,update on public.friend_requests to authenticated;
grant select on public.friendships to authenticated;

create or replace function public.respond_friend_request(p_request_id uuid,p_accept boolean)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_uid uuid:=auth.uid(); v_req public.friend_requests%rowtype; v_a uuid; v_b uuid;
begin
 if v_uid is null then raise exception 'login_required'; end if;
 select * into v_req from public.friend_requests where id=p_request_id for update;
 if not found then raise exception 'request_not_found'; end if;
 if v_req.receiver_id<>v_uid or v_req.status<>'pending' then raise exception 'not_allowed'; end if;
 update public.friend_requests set status=case when p_accept then 'accepted' else 'rejected' end, responded_at=now() where id=p_request_id;
 if p_accept then
  v_a:=least(v_req.sender_id,v_req.receiver_id); v_b:=greatest(v_req.sender_id,v_req.receiver_id);
  insert into public.friendships(user_a,user_b) values(v_a,v_b) on conflict do nothing;
  insert into public.notifications(user_id,actor_id,kind,title,body,payload)
  values(v_req.sender_id,v_uid,'friend_accepted','تم قبول طلب الصداقة','وافق عضو على طلب صداقتك',jsonb_build_object('friend_id',v_uid));
 end if;
 return jsonb_build_object('accepted',p_accept,'request_id',p_request_id);
end; $$;
revoke all on function public.respond_friend_request(uuid,boolean) from public,anon;
grant execute on function public.respond_friend_request(uuid,boolean) to authenticated;

-- Realtime delivery for room chat requires enabling room_messages in Supabase Realtime publication.
do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime')
 and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='room_messages') then
  alter publication supabase_realtime add table public.room_messages;
 end if;
exception when duplicate_object then null; end $$;
