-- WAVE Social starter schema. Apply to a new/test Supabase project first.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default 'عضو جديد',
  avatar_url text,
  country text,
  bio text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.admin_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin')),
  permissions jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint owner_has_all_permissions check (role <> 'owner' or permissions = '{"all": true}'::jsonb)
);

create table if not exists public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  target_user_id uuid references auth.users(id),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  coins bigint not null default 0 check (coins >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  asset_url text,
  coin_price bigint not null check (coin_price >= 0),
  animation_type text not null default 'overlay',
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.gift_transactions (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id),
  receiver_id uuid not null references auth.users(id),
  gift_id uuid not null references public.gifts(id),
  quantity integer not null default 1 check (quantity > 0),
  coins_spent bigint not null check (coins_spent >= 0),
  created_at timestamptz not null default now()
);

create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.admin_roles ar
    where ar.user_id = (select auth.uid()) and ar.role = 'owner'
  );
$$;

create or replace function public.has_admin_permission(permission_name text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.admin_roles ar
    where ar.user_id = (select auth.uid())
      and (ar.role = 'owner' or coalesce((ar.permissions ->> permission_name)::boolean, false))
  );
$$;

-- Bootstrap owner role only for the confirmed, exact owner email. Never trust a client-supplied role.
create or replace function public.bootstrap_wave_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  normalized_email text;
begin
  normalized_email := lower(coalesce(new.email, ''));
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data ->> 'display_name',''), 'عضو جديد'))
  on conflict (id) do nothing;
  insert into public.wallets(user_id) values (new.id) on conflict (user_id) do nothing;
  if normalized_email = 'hamadanagy1979@gmail.com' and new.email_confirmed_at is not null then
    insert into public.admin_roles(user_id, role, permissions)
    values (new.id, 'owner', '{"all": true}'::jsonb)
    on conflict (user_id) do update set role='owner', permissions='{"all": true}'::jsonb, updated_at=now();
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_wave on auth.users;
create trigger on_auth_user_created_wave after insert or update on auth.users
for each row execute function public.bootstrap_wave_user();

-- Only owner may create/revoke admins. Permission keys are explicitly selected by owner.
create or replace function public.owner_set_admin(target_email text, new_permissions jsonb, make_admin boolean default true)
returns void language plpgsql security definer set search_path = '' as $$
declare
  target_id uuid;
begin
  if not public.is_owner() then raise exception 'owner_only'; end if;
  select id into target_id from auth.users
   where lower(email)=lower(trim(target_email)) and email_confirmed_at is not null limit 1;
  if target_id is null then raise exception 'confirmed_user_not_found'; end if;
  if target_id = (select auth.uid()) then raise exception 'cannot_change_owner'; end if;
  if exists(select 1 from public.admin_roles where user_id=target_id and role='owner') then
    raise exception 'cannot_modify_owner';
  end if;
  if make_admin then
    insert into public.admin_roles(user_id, role, permissions, created_by, updated_at)
    values (target_id, 'admin', coalesce(new_permissions,'{}'::jsonb), (select auth.uid()), now())
    on conflict(user_id) do update set role='admin', permissions=excluded.permissions, created_by=excluded.created_by, updated_at=now();
    insert into public.admin_audit_log(actor_id, action, target_user_id, details)
    values ((select auth.uid()), 'admin_granted_or_updated', target_id, jsonb_build_object('permissions',coalesce(new_permissions,'{}'::jsonb)));
  else
    delete from public.admin_roles where user_id=target_id and role='admin';
    insert into public.admin_audit_log(actor_id, action, target_user_id)
    values ((select auth.uid()), 'admin_revoked', target_id);
  end if;
end;
$$;

alter table public.profiles enable row level security;
alter table public.admin_roles enable row level security;
alter table public.admin_audit_log enable row level security;
alter table public.wallets enable row level security;
alter table public.gifts enable row level security;
alter table public.gift_transactions enable row level security;

create policy "profiles readable by authenticated users" on public.profiles for select to authenticated using (true);
create policy "users update own profile" on public.profiles for update to authenticated using (id=(select auth.uid())) with check (id=(select auth.uid()));
create policy "owner and admins read roles" on public.admin_roles for select to authenticated using (public.is_owner() or public.has_admin_permission('manage_admins'));
create policy "owner reads audit log" on public.admin_audit_log for select to authenticated using (public.is_owner() or public.has_admin_permission('view_audit_log'));
create policy "wallet owner reads own wallet" on public.wallets for select to authenticated using (user_id=(select auth.uid()) or public.has_admin_permission('manage_wallets'));
create policy "enabled gifts visible" on public.gifts for select to authenticated using (enabled=true or public.has_admin_permission('manage_gifts'));
create policy "gift transactions visible to participants" on public.gift_transactions for select to authenticated using (sender_id=(select auth.uid()) or receiver_id=(select auth.uid()) or public.has_admin_permission('view_gift_transactions'));

revoke all on public.admin_roles from anon, authenticated;
grant select on public.admin_roles to authenticated;
revoke insert, update, delete on public.admin_roles from anon, authenticated;
revoke all on public.admin_audit_log from anon, authenticated;
grant select on public.admin_audit_log to authenticated;
revoke insert, update, delete on public.wallets from anon, authenticated;
grant select on public.wallets to authenticated;
grant select on public.gifts to authenticated;
grant select on public.gift_transactions to authenticated;
revoke insert, update, delete on public.gifts from anon, authenticated;
revoke insert, update, delete on public.gift_transactions from anon, authenticated;
revoke all on function public.owner_set_admin(text,jsonb,boolean) from public, anon;
grant execute on function public.owner_set_admin(text,jsonb,boolean) to authenticated;
revoke all on function public.is_owner() from public, anon;
grant execute on function public.is_owner() to authenticated;
revoke all on function public.has_admin_permission(text) from public, anon;
grant execute on function public.has_admin_permission(text) to authenticated;
