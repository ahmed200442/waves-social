-- WAVE Social migration 008: PK challenges.
create table if not exists public.pk_matches (
  id uuid primary key default gen_random_uuid(),
  challenger_id uuid not null references auth.users(id) on delete cascade,
  opponent_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','live','completed','declined','cancelled')),
  challenger_score integer not null default 0 check (challenger_score >= 0),
  opponent_score integer not null default 0 check (opponent_score >= 0),
  winner_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (challenger_id <> opponent_id)
);
create index if not exists pk_matches_participants_created_idx
  on public.pk_matches (challenger_id, opponent_id, created_at desc);
alter table public.pk_matches enable row level security;
drop policy if exists "participants read pk matches" on public.pk_matches;
create policy "participants read pk matches" on public.pk_matches
for select to authenticated
using (auth.uid() = challenger_id or auth.uid() = opponent_id);
drop policy if exists "challenger creates pk match" on public.pk_matches;
create policy "challenger creates pk match" on public.pk_matches
for insert to authenticated
with check (auth.uid() = challenger_id and status = 'pending' and challenger_score = 0 and opponent_score = 0 and winner_id is null);
grant select, insert on public.pk_matches to authenticated;
