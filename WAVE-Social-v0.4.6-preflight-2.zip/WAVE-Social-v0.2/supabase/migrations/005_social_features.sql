-- WAVE Social: foundational persistence for friends, live rooms, games, battles,
-- notifications, reports, and secure gift transactions. Apply after migrations 001-004.
create extension if not exists pgcrypto;

create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 actor_id uuid references auth.users(id) on delete set null, kind text not null,
 title text not null, body text not null default '', payload jsonb not null default '{}'::jsonb,
 read_at timestamptz, created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id,created_at desc);

create table if not exists public.user_reports (
 id uuid primary key default gen_random_uuid(), reporter_id uuid not null references auth.users(id) on delete cascade,
 target_user_id uuid references auth.users(id) on delete cascade, room_id uuid references public.rooms(id) on delete set null,
 category text not null, details text not null default '', status text not null default 'open' check(status in ('open','reviewing','resolved','dismissed')),
 handled_by uuid references auth.users(id), handled_at timestamptz, created_at timestamptz not null default now()
);

create table if not exists public.game_matches (
 id uuid primary key default gen_random_uuid(), game_type text not null check(game_type in ('ludo','pk')),
 status text not null default 'waiting' check(status in ('waiting','active','finished','cancelled')),
 host_id uuid not null references auth.users(id) on delete cascade, opponent_id uuid references auth.users(id) on delete set null,
 room_id uuid references public.rooms(id) on delete set null, state jsonb not null default '{}'::jsonb,
 host_score integer not null default 0, opponent_score integer not null default 0,
 winner_id uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.game_moves (
 id bigint generated always as identity primary key, match_id uuid not null references public.game_matches(id) on delete cascade,
 player_id uuid not null references auth.users(id) on delete cascade, move jsonb not null, created_at timestamptz not null default now()
);
create index if not exists game_matches_created_idx on public.game_matches(created_at desc);

create table if not exists public.room_events (
 id bigint generated always as identity primary key, room_id uuid not null references public.rooms(id) on delete cascade,
 actor_id uuid references auth.users(id) on delete set null, event_type text not null,
 payload jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

alter table public.notifications enable row level security;
alter table public.user_reports enable row level security;
alter table public.game_matches enable row level security;
alter table public.game_moves enable row level security;
alter table public.room_events enable row level security;

drop policy if exists notifications_owner_read on public.notifications;
create policy notifications_owner_read on public.notifications for select to authenticated using(user_id=(select auth.uid()));
create policy notifications_owner_update on public.notifications for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
revoke insert,delete on public.notifications from anon,authenticated;
grant select,update on public.notifications to authenticated;

create policy reports_submit_own on public.user_reports for insert to authenticated with check(reporter_id=(select auth.uid()));
create policy reports_participant_or_admin_read on public.user_reports for select to authenticated using(reporter_id=(select auth.uid()) or public.has_admin_permission('view_reports'));
create policy reports_admin_update on public.user_reports for update to authenticated using(public.has_admin_permission('view_reports')) with check(public.has_admin_permission('view_reports'));
grant select,insert,update on public.user_reports to authenticated;

create policy game_matches_participant_read on public.game_matches for select to authenticated using(host_id=(select auth.uid()) or opponent_id=(select auth.uid()) or status='waiting');
create policy game_matches_create_own on public.game_matches for insert to authenticated with check(host_id=(select auth.uid()));
create policy game_moves_participant_read on public.game_moves for select to authenticated using(exists(select 1 from public.game_matches m where m.id=match_id and (m.host_id=(select auth.uid()) or m.opponent_id=(select auth.uid()))));
grant select,insert,update on public.game_matches to authenticated;
grant select,insert on public.game_moves to authenticated;

create policy room_events_member_read on public.room_events for select to authenticated using(exists(select 1 from public.room_members rm where rm.room_id=room_events.room_id and rm.user_id=(select auth.uid())));
revoke insert,update,delete on public.room_events from anon,authenticated;
grant select on public.room_events to authenticated;

-- Secure gift RPC: price is read from the catalog and wallet debit + transaction
-- happen atomically. It never trusts a client-supplied price or balance.
create or replace function public.send_gift(p_receiver_id uuid,p_gift_id uuid,p_quantity integer default 1,p_room_id uuid default null)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_sender uuid:=auth.uid(); v_price bigint; v_total bigint; v_balance bigint; v_tx uuid;
begin
 if v_sender is null then raise exception 'login_required'; end if;
 if p_receiver_id is null or p_receiver_id=v_sender then raise exception 'invalid_receiver'; end if;
 if p_quantity is null or p_quantity<1 or p_quantity>100 then raise exception 'invalid_quantity'; end if;
 select coin_price into v_price from public.gifts where id=p_gift_id and enabled=true;
 if not found then raise exception 'gift_unavailable'; end if;
 if not exists(select 1 from public.profiles where id=p_receiver_id) then raise exception 'receiver_not_found'; end if;
 if p_room_id is not null and not exists(select 1 from public.rooms where id=p_room_id and is_active=true) then raise exception 'room_unavailable'; end if;
 v_total:=v_price*p_quantity;
 select coins into v_balance from public.wallets where user_id=v_sender for update;
 if not found then raise exception 'wallet_not_found'; end if;
 if v_balance<v_total then raise exception 'insufficient_coins'; end if;
 update public.wallets set coins=coins-v_total,updated_at=now() where user_id=v_sender;
 insert into public.gift_transactions(sender_id,receiver_id,gift_id,quantity,coins_spent)
 values(v_sender,p_receiver_id,p_gift_id,p_quantity,v_total) returning id into v_tx;
 insert into public.notifications(user_id,actor_id,kind,title,body,payload)
 values(p_receiver_id,v_sender,'gift','وصلتك هدية','أرسل لك عضو هدية',jsonb_build_object('gift_id',p_gift_id,'quantity',p_quantity,'transaction_id',v_tx,'room_id',p_room_id));
 insert into public.admin_audit_log(actor_id,action,target_user_id,details)
 values(v_sender,'gift_sent',p_receiver_id,jsonb_build_object('transaction_id',v_tx,'gift_id',p_gift_id,'quantity',p_quantity,'coins',v_total));
 return jsonb_build_object('transaction_id',v_tx,'coins_spent',v_total,'remaining_coins',v_balance-v_total);
end; $$;
revoke all on function public.send_gift(uuid,uuid,integer,uuid) from public,anon;
grant execute on function public.send_gift(uuid,uuid,integer,uuid) to authenticated;

-- Admin report queue remains permission-checked by RLS; owner audit log is append-only for clients.
