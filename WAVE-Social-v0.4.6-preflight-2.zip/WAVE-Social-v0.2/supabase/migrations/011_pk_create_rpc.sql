-- Secure PK creation: validate the invited account and prevent duplicate pending matches.
create or replace function public.create_pk_challenge(p_opponent_id uuid)
returns public.pk_matches
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  result public.pk_matches;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if p_opponent_id is null or p_opponent_id = auth.uid() then
    raise exception 'Invalid opponent';
  end if;

  if not exists (select 1 from auth.users u where u.id = p_opponent_id) then
    raise exception 'Opponent account not found';
  end if;

  if exists (
    select 1 from public.pk_matches m
     where m.status = 'pending'
       and ((m.challenger_id = auth.uid() and m.opponent_id = p_opponent_id)
         or (m.challenger_id = p_opponent_id and m.opponent_id = auth.uid()))
  ) then
    raise exception 'A pending challenge already exists between these accounts';
  end if;

  insert into public.pk_matches (challenger_id, opponent_id, status, challenger_score, opponent_score)
  values (auth.uid(), p_opponent_id, 'pending', 0, 0)
  returning * into result;

  return result;
end;
$$;

revoke all on function public.create_pk_challenge(uuid) from public;
grant execute on function public.create_pk_challenge(uuid) to authenticated;
-- Force clients through the validated RPC instead of inserting arbitrary participant rows.
revoke insert on public.pk_matches from authenticated;
