-- Secure PK response lifecycle: only the invited opponent can accept/decline.
create or replace function public.respond_pk_challenge(p_match_id uuid, p_accept boolean)
returns public.pk_matches
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  result public.pk_matches;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  update public.pk_matches
     set status = case when p_accept then 'accepted' else 'declined' end,
         updated_at = now()
   where id = p_match_id
     and opponent_id = auth.uid()
     and status = 'pending'
   returning * into result;
  if not found then
    raise exception 'Challenge not found, already answered, or not addressed to this user';
  end if;
  return result;
end;
$$;
revoke all on function public.respond_pk_challenge(uuid, boolean) from public;
grant execute on function public.respond_pk_challenge(uuid, boolean) to authenticated;
