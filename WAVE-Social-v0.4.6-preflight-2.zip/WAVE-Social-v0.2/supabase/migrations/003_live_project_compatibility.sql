-- Compatibility migration for the already-configured WAVE Supabase project.
-- Run this on that existing project, not after the alternate starter schema 001/002.
create unique index if not exists admins_single_owner_idx
on public.admins ((role)) where role = 'owner';

create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.admins a where a.user_id = (select auth.uid()) and a.role = 'owner');
$$;

create or replace function public.owner_set_admin(target_email text, new_permissions jsonb, make_admin boolean default true)
returns void language plpgsql security definer set search_path = '' as $$
declare target_id uuid;
begin
  if not public.is_owner() then raise exception 'owner_only'; end if;
  select u.id into target_id from auth.users u
  where lower(u.email) = lower(trim(target_email)) and u.email_confirmed_at is not null limit 1;
  if target_id is null then raise exception 'confirmed_user_not_found'; end if;
  if target_id = (select auth.uid()) then raise exception 'cannot_change_owner'; end if;
  if exists (select 1 from public.admins a where a.user_id = target_id and a.role = 'owner') then raise exception 'cannot_modify_owner'; end if;
  if make_admin then
    insert into public.admins(user_id, role, permissions, granted_by)
    values (target_id, 'admin', coalesce(new_permissions, '{}'::jsonb), (select auth.uid()))
    on conflict (user_id) do update set role='admin', permissions=excluded.permissions, granted_by=excluded.granted_by;
    insert into public.admin_audit_log(actor_id, action, target_type, target_id, details)
    values ((select auth.uid()), 'admin_granted_or_updated', 'user', target_id::text,
      jsonb_build_object('permissions', coalesce(new_permissions, '{}'::jsonb)));
  else
    delete from public.admins where user_id=target_id and role='admin';
    insert into public.admin_audit_log(actor_id, action, target_type, target_id, details)
    values ((select auth.uid()), 'admin_revoked', 'user', target_id::text, '{}'::jsonb);
  end if;
end;
$$;

create or replace function public.owner_revoke_admin(target_user uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'owner_only'; end if;
  if target_user = (select auth.uid()) then raise exception 'cannot_change_owner'; end if;
  if exists (select 1 from public.admins where user_id=target_user and role='owner') then raise exception 'cannot_modify_owner'; end if;
  delete from public.admins where user_id=target_user and role='admin';
  insert into public.admin_audit_log(actor_id, action, target_type, target_id, details)
  values ((select auth.uid()), 'admin_revoked', 'user', target_user::text, '{}'::jsonb);
end;
$$;

drop policy if exists "Owner can view all admin roles" on public.admins;
create policy "Owner can view all admin roles" on public.admins for select to authenticated using (public.is_owner());
revoke all on function public.is_owner() from public, anon;
grant execute on function public.is_owner() to authenticated;
revoke all on function public.owner_set_admin(text,jsonb,boolean) from public, anon;
grant execute on function public.owner_set_admin(text,jsonb,boolean) to authenticated;
revoke all on function public.owner_revoke_admin(uuid) from public, anon;
grant execute on function public.owner_revoke_admin(uuid) to authenticated;
