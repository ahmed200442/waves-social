-- Allow only the challenger to cancel their own pending PK challenge.
create or replace function public.cancel_pk_challenge(p_match_id uuid)
returns public.pk_matches
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  result public.pk_matches;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  update public.pk_matches
     set status = 'cancelled', updated_at = now()
   where id = p_match_id
     and challenger_id = auth.uid()
     and status = 'pending'
   returning * into result;

  if not found then
    raise exception 'Challenge not found, already answered, or not owned by this user';
  end if;

  return result;
end;
$$;

revoke all on function public.cancel_pk_challenge(uuid) from public;
grant execute on function public.cancel_pk_challenge(uuid) to authenticated;
