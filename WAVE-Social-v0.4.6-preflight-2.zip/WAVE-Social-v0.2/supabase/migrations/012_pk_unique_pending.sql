-- WAVE Social migration 012: make duplicate pending PK challenges impossible under concurrent requests.
-- Keep the oldest pending challenge for each unordered pair and cancel any legacy duplicates first.
with ranked_pending as (
  select id,
         row_number() over (
           partition by least(challenger_id, opponent_id), greatest(challenger_id, opponent_id)
           order by created_at asc, id asc
         ) as rn
    from public.pk_matches
   where status = 'pending'
)
update public.pk_matches m
   set status = 'cancelled', updated_at = now()
  from ranked_pending r
 where m.id = r.id and r.rn > 1;

create unique index if not exists pk_matches_one_pending_per_pair_uidx
  on public.pk_matches (
    least(challenger_id, opponent_id),
    greatest(challenger_id, opponent_id)
  )
  where status = 'pending';

-- Replace the creation RPC so a simultaneous request gets a clear, controlled error.
create or replace function public.create_pk_challenge(p_opponent_id uuid)
returns public.pk_matches
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  result public.pk_matches;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if p_opponent_id is null or p_opponent_id = auth.uid() then
    raise exception 'Invalid opponent';
  end if;

  if not exists (select 1 from auth.users u where u.id = p_opponent_id) then
    raise exception 'Opponent account not found';
  end if;

  if exists (
    select 1 from public.pk_matches m
     where m.status = 'pending'
       and least(m.challenger_id, m.opponent_id) = least(auth.uid(), p_opponent_id)
       and greatest(m.challenger_id, m.opponent_id) = greatest(auth.uid(), p_opponent_id)
  ) then
    raise exception 'A pending challenge already exists between these accounts';
  end if;

  insert into public.pk_matches (challenger_id, opponent_id, status, challenger_score, opponent_score)
  values (auth.uid(), p_opponent_id, 'pending', 0, 0)
  returning * into result;

  return result;
exception
  when unique_violation then
    raise exception 'A pending challenge already exists between these accounts';
end;
$$;

revoke all on function public.create_pk_challenge(uuid) from public;
grant execute on function public.create_pk_challenge(uuid) to authenticated;
