-- WAVE Social migration 007: private messages between accepted friends.
create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  message text not null check (char_length(trim(message)) between 1 and 2000),
  created_at timestamptz not null default now(),
  constraint direct_messages_not_self check (sender_id <> receiver_id)
);
create index if not exists direct_messages_pair_created_idx
  on public.direct_messages (sender_id, receiver_id, created_at);
alter table public.direct_messages enable row level security;
drop policy if exists "participants read direct messages" on public.direct_messages;
create policy "participants read direct messages" on public.direct_messages
for select to authenticated
using (auth.uid() = sender_id or auth.uid() = receiver_id);
drop policy if exists "friends send direct messages" on public.direct_messages;
create policy "friends send direct messages" on public.direct_messages
for insert to authenticated
with check (
  auth.uid() = sender_id
  and exists (
    select 1 from public.friendships f
    where (f.user_a = sender_id and f.user_b = receiver_id)
       or (f.user_a = receiver_id and f.user_b = sender_id)
  )
);
grant select, insert on public.direct_messages to authenticated;
do $$
begin
  alter publication supabase_realtime add table public.direct_messages;
exception when duplicate_object then null;
when undefined_object then null;
when insufficient_privilege then null;
end $$;
