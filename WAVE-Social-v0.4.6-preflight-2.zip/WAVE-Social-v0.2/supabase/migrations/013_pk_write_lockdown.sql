-- WAVE Social migration 013: close direct table-write paths for PK challenges.
-- All lifecycle changes must go through the validated SECURITY DEFINER RPCs.

alter table public.pk_matches enable row level security;

-- Remove any broad privileges that may have been granted by earlier schema setup.
revoke all on table public.pk_matches from anon;
revoke all on table public.pk_matches from authenticated;
revoke all on table public.pk_matches from public;

-- Participants can read their own challenge rows; no client can directly insert,
-- update scores/status/winner, or delete a challenge.
grant select on table public.pk_matches to authenticated;

-- Keep only the intended RPC entry points callable by signed-in users.
revoke all on function public.create_pk_challenge(uuid) from public;
revoke all on function public.respond_pk_challenge(uuid, boolean) from public;
revoke all on function public.cancel_pk_challenge(uuid) from public;
revoke all on function public.create_pk_challenge(uuid) from anon;
revoke all on function public.respond_pk_challenge(uuid, boolean) from anon;
revoke all on function public.cancel_pk_challenge(uuid) from anon;
grant execute on function public.create_pk_challenge(uuid) to authenticated;
grant execute on function public.respond_pk_challenge(uuid, boolean) to authenticated;
grant execute on function public.cancel_pk_challenge(uuid) to authenticated;
