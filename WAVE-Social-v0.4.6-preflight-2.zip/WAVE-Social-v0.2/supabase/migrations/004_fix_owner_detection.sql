-- Ensure owner detection reads the same public.admins table used by the app.
create or replace function public.is_owner()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.admins as a
    where a.user_id = (select auth.uid())
      and a.role = 'owner'
  );
$$;

revoke all on function public.is_owner() from public, anon;
grant execute on function public.is_owner() to authenticated;
