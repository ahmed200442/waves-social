-- WAVE Social v0.2 extension. Apply after 001_initial_schema.sql.
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  room_type text not null default 'public' check (room_type in ('public','private')),
  created_by uuid not null references auth.users(id) on delete cascade,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  seat_number integer,
  mic_enabled boolean not null default false,
  joined_at timestamptz not null default now(),
  primary key(room_id,user_id),
  unique(room_id,seat_number)
);
create table if not exists public.friendships (
  requester_id uuid not null references auth.users(id) on delete cascade,
  addressee_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check(status in ('pending','accepted','blocked')),
  created_at timestamptz not null default now(),
  primary key(requester_id,addressee_id),
  check(requester_id <> addressee_id)
);
create table if not exists public.room_messages (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  message text not null check(char_length(message) between 1 and 1000),
  created_at timestamptz not null default now()
);

-- Bootstrap on insert/update so an existing owner account becomes owner after email confirmation.
create or replace function public.bootstrap_wave_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare normalized_email text;
begin
  normalized_email := lower(coalesce(new.email,''));
  insert into public.profiles(id,display_name)
    values(new.id,coalesce(nullif(new.raw_user_meta_data ->> 'display_name',''),'عضو جديد'))
    on conflict(id) do nothing;
  insert into public.wallets(user_id) values(new.id) on conflict(user_id) do nothing;
  if normalized_email='hamadanagy1979@gmail.com' and new.email_confirmed_at is not null then
    insert into public.admin_roles(user_id,role,permissions)
      values(new.id,'owner','{"all": true}'::jsonb)
      on conflict(user_id) do update set role='owner',permissions='{"all": true}'::jsonb,updated_at=now();
  end if;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_wave on auth.users;
create trigger on_auth_user_created_wave after insert or update on auth.users
for each row execute function public.bootstrap_wave_user();

create or replace function public.owner_revoke_admin(target_user uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'owner_only'; end if;
  if target_user=(select auth.uid()) then raise exception 'cannot_change_owner'; end if;
  if exists(select 1 from public.admin_roles where user_id=target_user and role='owner') then
    raise exception 'cannot_modify_owner';
  end if;
  delete from public.admin_roles where user_id=target_user and role='admin';
  insert into public.admin_audit_log(actor_id,action,target_user_id)
    values((select auth.uid()),'admin_revoked',target_user);
end;
$$;

alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.friendships enable row level security;
alter table public.room_messages enable row level security;
create policy "active rooms readable" on public.rooms for select to authenticated
  using(is_active=true or public.has_admin_permission('manage_rooms'));
create policy "members create rooms" on public.rooms for insert to authenticated
  with check(created_by=(select auth.uid()));
create policy "room creators or admins update rooms" on public.rooms for update to authenticated
  using(created_by=(select auth.uid()) or public.has_admin_permission('manage_rooms'))
  with check(created_by=(select auth.uid()) or public.has_admin_permission('manage_rooms'));
create policy "room members readable" on public.room_members for select to authenticated using(true);
create policy "users join themselves" on public.room_members for insert to authenticated
  with check(user_id=(select auth.uid()));
create policy "users update own room membership" on public.room_members for update to authenticated
  using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy "friendship participants read" on public.friendships for select to authenticated
  using(requester_id=(select auth.uid()) or addressee_id=(select auth.uid()));
create policy "users send friend requests" on public.friendships for insert to authenticated
  with check(requester_id=(select auth.uid()) and status='pending');
create policy "addressee responds to requests" on public.friendships for update to authenticated
  using(addressee_id=(select auth.uid())) with check(addressee_id=(select auth.uid()));
create policy "room members read messages" on public.room_messages for select to authenticated
  using(exists(select 1 from public.room_members rm where rm.room_id=room_messages.room_id and rm.user_id=(select auth.uid())));
create policy "room members send messages" on public.room_messages for insert to authenticated
  with check(user_id=(select auth.uid()) and exists(select 1 from public.room_members rm where rm.room_id=room_messages.room_id and rm.user_id=(select auth.uid())));

grant select,insert,update on public.rooms to authenticated;
grant select,insert,update on public.room_members to authenticated;
grant select,insert,update on public.friendships to authenticated;
grant select,insert on public.room_messages to authenticated;
revoke all on function public.owner_revoke_admin(uuid) from public,anon;
grant execute on function public.owner_revoke_admin(uuid) to authenticated;
insert into public.gifts(name,coin_price,animation_type)
select seed.name,seed.price,seed.animation from (values
 ('وردة',10,'sparkle'),('ماسة',100,'shine'),('تاج ملكي',500,'crown'),('سيارة أسطورية',5000,'full-screen')
) as seed(name,price,animation)
where not exists(select 1 from public.gifts g where g.name=seed.name);
