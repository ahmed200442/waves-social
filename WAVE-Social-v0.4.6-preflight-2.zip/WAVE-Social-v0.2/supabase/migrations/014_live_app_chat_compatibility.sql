-- Compatibility layer for the existing WAVE database schema.
-- Review against a staging/backup first. This migration adds only missing chat tables.
create table if not exists public.room_messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  message text not null check (char_length(trim(message)) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index if not exists room_messages_room_created_idx on public.room_messages(room_id, created_at);
alter table public.room_messages enable row level security;
drop policy if exists wave_room_messages_member_read on public.room_messages;
create policy wave_room_messages_member_read on public.room_messages for select to authenticated
using (exists (select 1 from public.room_members rm where rm.room_id=room_messages.room_id and rm.user_id=(select auth.uid())));
drop policy if exists wave_room_messages_member_insert on public.room_messages;
create policy wave_room_messages_member_insert on public.room_messages for insert to authenticated
with check (user_id=(select auth.uid()) and exists (select 1 from public.room_members rm where rm.room_id=room_messages.room_id and rm.user_id=(select auth.uid())));
grant select, insert on public.room_messages to authenticated;

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','cancelled')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  check (sender_id <> receiver_id),
  unique(sender_id, receiver_id)
);
create index if not exists wave_friend_requests_receiver_idx on public.friend_requests(receiver_id, status, created_at desc);
alter table public.friend_requests enable row level security;
drop policy if exists wave_friend_requests_read on public.friend_requests;
create policy wave_friend_requests_read on public.friend_requests for select to authenticated
using (sender_id=(select auth.uid()) or receiver_id=(select auth.uid()));
drop policy if exists wave_friend_requests_create on public.friend_requests;
create policy wave_friend_requests_create on public.friend_requests for insert to authenticated
with check (sender_id=(select auth.uid()) and status='pending' and receiver_id<>(select auth.uid()));
drop policy if exists wave_friend_requests_receiver_update on public.friend_requests;
-- Status changes must go through the validating RPC; clients cannot rewrite sender/receiver IDs.
revoke update on public.friend_requests from authenticated;
grant select, insert on public.friend_requests to authenticated;

create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  message text not null check (char_length(trim(message)) between 1 and 2000),
  created_at timestamptz not null default now(),
  check (sender_id <> receiver_id)
);
create index if not exists wave_direct_messages_pair_created_idx on public.direct_messages(sender_id, receiver_id, created_at);
alter table public.direct_messages enable row level security;
drop policy if exists wave_direct_messages_read on public.direct_messages;
create policy wave_direct_messages_read on public.direct_messages for select to authenticated
using (sender_id=(select auth.uid()) or receiver_id=(select auth.uid()));
drop policy if exists wave_direct_messages_send on public.direct_messages;
create policy wave_direct_messages_send on public.direct_messages for insert to authenticated
with check (sender_id=(select auth.uid()) and exists (
 select 1 from public.friendships f where f.status='accepted' and
 ((f.requester_id=sender_id and f.addressee_id=receiver_id) or (f.addressee_id=sender_id and f.requester_id=receiver_id))
));
grant select, insert on public.direct_messages to authenticated;

do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') then
  if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='room_messages') then alter publication supabase_realtime add table public.room_messages; end if;
  if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='direct_messages') then alter publication supabase_realtime add table public.direct_messages; end if;
 end if;
exception when insufficient_privilege then null; when undefined_object then null; end $$;

-- Keep the live project's friendship representation (requester_id/addressee_id/status)
-- synchronized when a request is accepted.
create or replace function public.respond_friend_request(p_request_id uuid, p_accept boolean)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_uid uuid := auth.uid(); v_req public.friend_requests%rowtype;
begin
 if v_uid is null then raise exception 'login_required'; end if;
 select * into v_req from public.friend_requests where id=p_request_id for update;
 if not found then raise exception 'request_not_found'; end if;
 if v_req.receiver_id<>v_uid or v_req.status<>'pending' then raise exception 'not_allowed'; end if;
 update public.friend_requests set status=case when p_accept then 'accepted' else 'rejected' end, responded_at=now() where id=p_request_id;
 if p_accept then
  insert into public.friendships(requester_id,addressee_id,status)
  values (v_req.sender_id,v_req.receiver_id,'accepted')
  on conflict (requester_id,addressee_id) do update set status='accepted';
 end if;
 return jsonb_build_object('accepted',p_accept,'request_id',p_request_id);
end; $$;
revoke all on function public.respond_friend_request(uuid,boolean) from public,anon;
grant execute on function public.respond_friend_request(uuid,boolean) to authenticated;
