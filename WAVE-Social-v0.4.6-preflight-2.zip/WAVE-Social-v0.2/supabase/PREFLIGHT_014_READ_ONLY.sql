-- WAVE Social: READ-ONLY preflight for migration 014.
-- Run in Supabase SQL Editor BEFORE applying migration 014.
-- This script makes no database changes and tolerates missing optional tables.

-- 1) Required tables/columns and chat compatibility tables already present.
select t.table_name,
       bool_or(c.column_name = 'id') as has_id,
       array_agg(c.column_name order by c.ordinal_position) filter (where c.column_name is not null) as columns_found
from information_schema.tables t
left join information_schema.columns c
  on c.table_schema = t.table_schema and c.table_name = t.table_name
where t.table_schema = 'public'
  and t.table_name in ('rooms','room_members','friendships','room_messages','friend_requests','direct_messages')
group by t.table_name
order by t.table_name;

-- 2) Required live-schema columns. A missing row means that column is absent.
select required.table_name, required.column_name,
       (c.column_name is not null) as exists_now,
       c.data_type
from (values
  ('rooms','id'),
  ('room_members','room_id'), ('room_members','user_id'),
  ('friendships','requester_id'), ('friendships','addressee_id'), ('friendships','status')
) as required(table_name, column_name)
left join information_schema.columns c
  on c.table_schema='public'
 and c.table_name=required.table_name
 and c.column_name=required.column_name
order by required.table_name, required.column_name;

-- 3) Inspect all current indexes on friendships; migration 014's ON CONFLICT
-- requires a unique index/constraint matching (requester_id, addressee_id).
select i.relname as index_name, ix.indisunique as is_unique,
       pg_get_indexdef(ix.indexrelid) as index_definition
from pg_class t
join pg_namespace n on n.oid = t.relnamespace
join pg_index ix on ix.indrelid = t.oid
join pg_class i on i.oid = ix.indexrelid
where n.nspname = 'public' and t.relname = 'friendships'
order by i.relname;


-- 3a) Duplicate friendship pairs. Any rows returned must be reconciled before
-- creating a unique index or relying on ON CONFLICT in migration 014.
select requester_id, addressee_id, count(*) as duplicate_count
from public.friendships
where requester_id is not null and addressee_id is not null
group by requester_id, addressee_id
having count(*) > 1
order by duplicate_count desc, requester_id, addressee_id;

-- 3b) Exact unique-index readiness for ON CONFLICT (requester_id, addressee_id).
-- This reports matching unique indexes only; it does not create or change anything.
select i.relname as matching_unique_index,
       pg_get_indexdef(ix.indexrelid) as index_definition
from pg_class t
join pg_namespace n on n.oid = t.relnamespace
join pg_index ix on ix.indrelid = t.oid
join pg_class i on i.oid = ix.indexrelid
where n.nspname = 'public'
  and t.relname = 'friendships'
  and ix.indisunique
  and ix.indisvalid
  and ix.indpred is null
  and (select array_agg(a.attname order by k.ordinality)
       from unnest(ix.indkey) with ordinality as k(attnum, ordinality)
       join pg_attribute a on a.attrelid=t.oid and a.attnum=k.attnum
       where k.ordinality <= ix.indnkeyatts)
      = array['requester_id','addressee_id']::name[];

-- 4) Friendship constraints (safe even if the table is absent).
select c.conname, pg_get_constraintdef(c.oid) as definition
from pg_constraint c
join pg_class t on t.oid = c.conrelid
join pg_namespace n on n.oid = t.relnamespace
where n.nspname='public' and t.relname='friendships'
order by c.conname;

-- 6) Check whether Supabase Realtime publication exists and which relevant tables it contains.
select pubname from pg_publication where pubname = 'supabase_realtime';
select schemaname, tablename
from pg_publication_tables
where pubname = 'supabase_realtime'
  and schemaname = 'public'
  and tablename in ('room_messages','direct_messages')
order by tablename;

-- 7) Check RLS status on current and future chat tables.
select t.tablename, t.rowsecurity as rls_enabled
from pg_tables p
join pg_class t ON t.relname = p.tablename
join pg_namespace n ON n.oid = t.relnamespace AND n.nspname = p.schemaname
where p.schemaname='public'
  and p.tablename in ('room_messages','friend_requests','direct_messages')
order by p.tablename;

-- 5) Review current friendship policies before migration 014.
select polname, pg_get_expr(polqual, polrelid) as using_expression,
       pg_get_expr(polwithcheck, polrelid) as check_expression, polcmd, polroles
from pg_policy
where polrelid = to_regclass('public.friendships')
order by polname;

-- IMPORTANT: Do not apply migration 014 until you verify:
-- * all required base columns above exist;
-- * friendships has a unique index on (requester_id, addressee_id);
-- * existing duplicate friendship pairs have been ruled out;
-- * current RLS policies and app schema have been backed up/reviewed.
