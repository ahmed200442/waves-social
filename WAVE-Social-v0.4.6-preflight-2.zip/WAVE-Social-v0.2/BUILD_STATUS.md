# WAVE Social — Build and deployment status

Package label: v0.4.6-preflight (source/preflight package; app version remains 0.4.3 / Android versionCode 8).

## Verified in this package
- ZIP archive integrity checked.
- `.env` excluded; `.env.example` retained if present.
- Added and hardened `supabase/PREFLIGHT_014_READ_ONLY.sql`: read-only checks for required columns, friendship indexes/constraints, duplicate friendship pairs, exact unique-index readiness for ON CONFLICT, current friendship policies, Realtime membership, and RLS state.

## Not verified / not completed
- No successful TypeScript check: dependencies were not installed successfully in the execution environment.
- No successful Android Gradle build; no new APK produced.
- Migration 014 has not been applied to the live Supabase project.
- No GitHub push or Actions workflow run was performed.

## Safe next steps
1. Run `supabase/PREFLIGHT_014_READ_ONLY.sql` in Supabase SQL Editor and review its output.
2. Review every result from `supabase/PREFLIGHT_014_READ_ONLY.sql`; confirm the unique index on `(requester_id, addressee_id)` and required columns exist before considering migration 014. The preflight is diagnostic only and does not authorize applying the migration automatically.
3. Set GitHub Actions repository secrets `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
4. Run the Android workflow and inspect the actual build logs before distributing an APK.
