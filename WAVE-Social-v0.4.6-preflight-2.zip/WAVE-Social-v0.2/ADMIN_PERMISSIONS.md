# WAVE owner and admin permissions

Owner email: `hamadanagy1979@gmail.com`.

The owner role is stored in `public.admin_roles` and checked via `public.is_owner()`. Database RPCs enforce owner-only grant/revoke operations. Additional admins can receive selected permissions:
- `manage_members`
- `manage_rooms`
- `manage_gifts`
- `manage_wallets`
- `view_reports`
- `view_audit_log`

The current UI offers these permission toggles. The corresponding full admin feature screens and permission-specific server operations still need implementation. Do not place a Supabase `service_role` key in the client.
